# 🧠 Object Detection Models for Pavement Deformation Distress

This repository contains trained object detection models implemented using:
- YOLOv5
- YOLOv6
- YOLOv7
- YOLOv8
- Faster R-CNN

Each model was trained on the same dataset to provide a fair comparison in terms of performance, ease of use, and implementation characteristics.


## 📁 Files Included

| File Name            | Model         | Framework     | Description                                |
|----------------------|---------------|---------------|--------------------------------------------|
| `Yolov5.ipynb`       | YOLOv5        | PyTorch       | YOLOv5 training and inference notebook     |
| `Yolov6.ipynb`       | YOLOv6        | PyTorch       | YOLOv6 training and inference notebook     |
| `Yolov7.ipynb`       | YOLOv7        | PyTorch       | YOLOv7 training and inference notebook     |
| `Yolov8.ipynb`       | YOLOv8        | Ultralytics   | YOLOv8 training and inference notebook     |
| `Faster_RCNN.ipynb`  | Faster R-CNN  | torchvision   | Faster R-CNN                               |



## 🎯 Objective

The goal of this project is to:
- Compare various object detection architectures using a unified dataset
- Evaluate model accuracy, training time, and inference performance
- Provide reproducible training workflows in Jupyter notebooks



## 🚀 Getting Started

Clone the repository and open any of the Jupyter notebooks to run the code.

```bash
git clone https://github.com/agolroo/Pavement_Deformation_Distress_Dataset.git
cd Pavement_Deformation_Distress_Dataset
jupyter notebook
```



## 🧪 Dataset
The annotated dataset used in this research is available on Attain website (https://attain.aut.ac.ir/Datasets).



## 📌 Notes
These notebooks are ideal for learning, benchmarking, and experimentation.

You can extend this repo by integrating newer models or additional evaluation tools.

Make sure your environment includes necessary dependencies.



## 🤝 Contributing
Feel free to open a PR or issue if you'd like to:

- Add new models
- Improve evaluation
- Automate benchmarking


## 📬 Contact
For questions or feedback, open an issue or reach out via GitHub.